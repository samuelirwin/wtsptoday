

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create Link</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="get" action="<?php echo e(route('user.link.store')); ?>">

			            <!-- CROSS Site Request Forgery Protection -->
			            <?php echo csrf_field(); ?>

			            <div class="form-group">
			                <label>Custom name (subdomain)</label>
			                <input type="text" class="form-control" name="subdomain" id="subdomain">
			            </div>

			            <div class="form-group">
			                <label>Mobile no</label>
			                <input type="text" class="form-control" name="mobile_no" id="mobileNo">
			            </div>

			            <div class="form-group">
			                <label>Custom message</label>
			                <textarea class="form-control" name="custom_message" id="customMessage" rows="4"></textarea>
			            </div>

			            <input type="submit" value="Create link" class="btn btn-dark btn-block">
			        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wtsptoday\resources\views/links/create.blade.php ENDPATH**/ ?>